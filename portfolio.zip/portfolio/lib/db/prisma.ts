import "server-only";
import { PrismaClient } from "@prisma/client";
import { PrismaPg } from "@prisma/adapter-pg";
import { Pool } from "pg";

const globalForPrisma = globalThis as unknown as {
    prisma: PrismaClient | undefined;
    pgPool: Pool | undefined;
};

function getPool() {
    if (globalForPrisma.pgPool) return globalForPrisma.pgPool;

    const connectionString = process.env.DATABASE_URL;
    if (!connectionString) {
        throw new Error("DATABASE_URL is not set");
    }

    // Create a single pool for the whole app (important with Next dev / hot reload)
    const pool = new Pool({
        connectionString,
        // optional: tune if needed
        // max: 10,
        // idleTimeoutMillis: 30_000,
    });

    globalForPrisma.pgPool = pool;
    return pool;
}

export const prisma =
    globalForPrisma.prisma ??
    new PrismaClient({
        adapter: new PrismaPg(getPool()),
        log: process.env.NODE_ENV === "development" ? ["query", "error", "warn"] : ["error"],
    });

if (process.env.NODE_ENV !== "production") globalForPrisma.prisma = prisma;
