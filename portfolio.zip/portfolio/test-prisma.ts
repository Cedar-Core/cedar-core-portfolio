import { PrismaClient } from '@prisma/client';
const prisma = new PrismaClient();

async function main() {
    try {
        console.log('--- Testing Prisma ---');
        // Try to count users to see if the table exists and model is recognized
        const count = await prisma.user.count();
        console.log('User count:', count);
    } catch (err) {
        console.error('Prisma Test Failed:');
        console.error(err);
    } finally {
        await prisma.$disconnect();
    }
}

main();
